to run the project:

> python memh.py < trace.dat

it will assume there is a trace.config file in the current directory
project written in python 3
packages used: math, sys, time.